package com.example.spendwiseai

import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.annotation.RequiresApi
import com.example.spendwiseai.databinding.FragmentCreateGoalSheetBinding
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import java.time.YearMonth
import androidx.fragment.app.activityViewModels
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class CreateGoalSheet : BottomSheetDialogFragment() {

    private val viewModel: AnalysisViewModel by activityViewModels()
    private lateinit var binding: FragmentCreateGoalSheetBinding
    private var targetYearMonth: YearMonth? = null
    private var startYearMonth: YearMonth? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentCreateGoalSheetBinding.inflate(inflater, container, false)
        return binding.root
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.startMonthRow.setOnClickListener {
            val picker = GoalMonthYearPickerFragment { selected ->
                val formatted = "${selected.month.name.lowercase().replaceFirstChar { it.uppercase() }} ${selected.year}"
                binding.startMonthText.text = formatted
                startYearMonth = selected
            }
            picker.show(parentFragmentManager, "startMonthPicker")
        }

        binding.targetMonthRow.setOnClickListener {
            val picker = GoalMonthYearPickerFragment { selected ->

                val formatted = "${
                    selected.month.name.lowercase().replaceFirstChar { it.uppercase() }
                } ${selected.year}"

                binding.targetMonthText.text = formatted
                targetYearMonth = selected
            }

            picker.show(parentFragmentManager, "monthYearPicker")
        }

        binding.save.setOnClickListener {

            val user = FirebaseAuth.getInstance().currentUser

            if (user == null) {
                Toast.makeText(requireContext(), "Not logged in", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val name = binding.goalTitleInput.text.toString()
            val amountText = binding.targetAmount.text.toString()
            val deadlineText = binding.targetMonthText.text.toString()
            val startText = binding.startMonthText.text.toString()

            if (name.isEmpty()) {
                binding.goalTitleInput.error = "Please enter goal name"; return@setOnClickListener
            }
            if (amountText.isEmpty()) {
                binding.targetAmount.error = "Please enter target amount"; return@setOnClickListener
            }
            if (startYearMonth == null) { Toast.makeText(requireContext(), "Please select a start month", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            if (targetYearMonth == null) { Toast.makeText(requireContext(), "Please select a target month", Toast.LENGTH_SHORT).show(); return@setOnClickListener }

            val goal = Goal(
                name = name,
                targetAmount = amountText.toFloat(),
                savedAmount = 0f,
                startMonth = startText,
                deadline = deadlineText
            )



            val db = FirebaseFirestore.getInstance()
            db.collection("users")
                .document(user.uid)
                .collection("goals")
                .add(goal)
                .addOnSuccessListener { docRef ->
                    val goalWithId = goal.copy(id = docRef.id)
                    docRef.update("id", docRef.id)
                    viewModel.addGoal(goalWithId)
                    dismiss()
                }.addOnFailureListener { e ->
                    Toast.makeText(requireContext(), "Failed to save goal: ${e.message}",
                        Toast.LENGTH_SHORT).show()
                }
        }
    }
}