package com.example.spendwiseai

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.spendwiseai.R
import com.example.spendwiseai.Goal
import kotlin.div
import kotlin.text.toInt
import kotlin.times

class GoalAdapter(
    private val goals: MutableList<Goal>,
    private val onEditClick: (Goal) -> Unit
) : RecyclerView.Adapter<GoalAdapter.GoalViewHolder>() {

    class GoalViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val name: TextView = view.findViewById(R.id.goalName)
        val detail: TextView = view.findViewById(R.id.goalDetail)
        val progress: ProgressBar = view.findViewById(R.id.goalProgress)
        val edit: TextView = view.findViewById(R.id.editGoalLink)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GoalViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_goal, parent, false)
        return GoalViewHolder(view)
    }

    override fun onBindViewHolder(holder: GoalViewHolder, position: Int) {
        val goal = goals[position]
        val progressPercent = if (goal.targetAmount > 0f) {
            ((goal.savedAmount / goal.targetAmount) * 100).toInt().coerceIn(0, 100)
        } else 0

        val remaining = (goal.targetAmount - goal.savedAmount).coerceAtLeast(0f)

        holder.name.text = goal.name
        holder.detail.text = "RM${goal.targetAmount.toInt()} by ${goal.deadline}. RM${remaining.toInt()} more to go!"
        holder.progress.progress = progressPercent

        holder.itemView.setOnClickListener {
            onEditClick(goal)
        }
    }

    override fun getItemCount() = goals.size

    fun addGoal(goal: Goal) {
        goals.add(goal)
        notifyItemInserted(goals.size - 1)
    }
}