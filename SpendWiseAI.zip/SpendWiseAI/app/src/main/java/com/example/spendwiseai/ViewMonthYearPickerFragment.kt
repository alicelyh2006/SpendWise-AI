package com.example.spendwiseai

import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.NumberPicker
import androidx.annotation.RequiresApi
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import java.time.Year
import java.time.YearMonth

class ViewMonthYearPickerFragment(
    private val onDateSelected: (YearMonth) -> Unit
) : BottomSheetDialogFragment() {

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_month_year_picker, container, false)

        val monthPicker = view.findViewById<NumberPicker>(R.id.monthPicker)
        val yearPicker = view.findViewById<NumberPicker>(R.id.yearPicker)
        val confirmButton = view.findViewById<Button>(R.id.confirmButton)

        val  months = arrayOf(
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        )

        monthPicker.minValue = 0
        monthPicker.maxValue = 11
        monthPicker.displayedValues = months

        val currentYear = Year.now().value
        val currentMonth = YearMonth.now().monthValue
        yearPicker.minValue = currentYear - 10
        yearPicker.maxValue = currentYear
        yearPicker.value = currentYear
        monthPicker.value = currentMonth - 1

        fun updateMonthRange() {
            if (yearPicker.value == currentYear) {
                monthPicker.maxValue = currentMonth - 1
            } else {
                monthPicker.maxValue = 11
            }
        }

        updateMonthRange()

        yearPicker.setOnValueChangedListener { _, _, _ ->
            updateMonthRange()
            if (monthPicker.value > monthPicker.maxValue) {
                monthPicker.value = monthPicker.maxValue
            }
        }

        confirmButton.setOnClickListener {
            val selectedMonth = monthPicker.value + 1
            val selectedYear = yearPicker.value
            val selectedDate = YearMonth.of(selectedYear, selectedMonth)
            onDateSelected(selectedDate)
            dismiss()
        }
        return view
    }

}