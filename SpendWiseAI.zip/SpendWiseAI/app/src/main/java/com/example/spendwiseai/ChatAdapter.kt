package com.example.spendwiseai

import android.view.Gravity
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.core.text.PrecomputedTextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.spendwiseai.databinding.ItemMessageBinding

class ChatAdapter(private val messages: MutableList<MessageModel>) :
    RecyclerView.Adapter<ChatAdapter.ChatViewHolder>() {

    class ChatViewHolder(val binding: ItemMessageBinding)
        : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChatViewHolder {
        val binding = ItemMessageBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ChatViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ChatViewHolder, position: Int) {

        val message = messages[position]

        holder.binding.messageText.text = parseMarkdown(message.message)

        val params = holder.binding.messageText.layoutParams as LinearLayout.LayoutParams

        if (message.role == "user") {
            params.gravity = Gravity.END
            holder.binding.messageText.setBackgroundResource(R.drawable.bg_user_message)
        } else {
            params.gravity = Gravity.START
            holder.binding.messageText.setBackgroundResource(R.drawable.bg_bot_message)
        }

        holder.binding.messageText.layoutParams = params
    }

    override fun getItemCount(): Int = messages.size
}