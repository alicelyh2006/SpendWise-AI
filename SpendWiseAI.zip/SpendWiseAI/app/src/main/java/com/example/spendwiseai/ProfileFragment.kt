package com.example.spendwiseai

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class ProfileFragment : Fragment(R.layout.fragment_profile) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val profileName = view.findViewById<TextView>(R.id.profileName)
        val emailViewText = view.findViewById<TextView>(R.id.email)
        val logoutButton = view.findViewById<Button>(R.id.logoutButton)
        val deleteButton = view.findViewById<Button>(R.id.deleteAccountButton)

        val auth = FirebaseAuth.getInstance()
        val currentUser = auth.currentUser

        emailViewText.text = currentUser?.email ?: "Email unavailable."

        if (currentUser != null) {
            FirebaseFirestore.getInstance()
                .collection("users")
                .document(currentUser.uid)
                .get()
                .addOnSuccessListener { doc ->
                    profileName.text = doc.getString("name") ?: "User"
                }
                .addOnFailureListener {
                    profileName.text = "User"
                }
        }

        logoutButton.setOnClickListener {
            auth.signOut()
            val intent = Intent(requireActivity(), LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
        }

        deleteButton.setOnClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle("Delete Account")
                .setMessage("Are you sure you want to delete your account?\n\nThis is irreversible — all your data will be permanently lost.")
                .setPositiveButton("Yes, Delete") { _, _ ->
                    deleteAccount()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun deleteAccount() {
        val auth = FirebaseAuth.getInstance()
        val currentUser = auth.currentUser ?: return
        val uid = currentUser.uid

        // Step 1: Delete Firestore user data first
        FirebaseFirestore.getInstance()
            .collection("users")
            .document(uid)
            .delete()
            .addOnSuccessListener {
                // Step 2: Delete the Firebase Auth account
                currentUser.delete()
                    .addOnSuccessListener {
                        Toast.makeText(requireContext(), "Account deleted successfully.", Toast.LENGTH_SHORT).show()
                        val intent = Intent(requireActivity(), LoginActivity::class.java)
                        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                        startActivity(intent)
                    }
                    .addOnFailureListener {
                        // Firebase requires a recent login to delete the Auth account
                        Toast.makeText(
                            requireContext(),
                            "Failed to delete account. Please log out and log back in, then try again.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
            }
            .addOnFailureListener { e ->
                Toast.makeText(requireContext(), "Failed to delete data: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }
}