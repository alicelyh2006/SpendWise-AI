package com.example.spendwiseai

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class RecordAdapter(
        private val records: MutableList<Pair<String, Record>>,
        private val onDeleteClick: (String) -> Unit
) : RecyclerView.Adapter<RecordAdapter.RecordViewHolder>() {

class RecordViewHolder(view: View) : RecyclerView.ViewHolder(view) {
    val remark: TextView = view.findViewById(R.id.recordRemark)
    val expense: TextView = view.findViewById(R.id.recordExpense)
    val income: TextView = view.findViewById(R.id.recordIncome)
    val notes: TextView = view.findViewById(R.id.recordNotes)
    val deleteBtn: ImageButton = view.findViewById(R.id.deleteBtn)
}

override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecordViewHolder {
    val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_record, parent, false)
    return RecordViewHolder(view)
}

override fun onBindViewHolder(holder: RecordViewHolder, position: Int) {
    val (docId, record) = records[position]

    holder.remark.text = if (record.remark.isNotBlank()) record.remark else "No remark"
    holder.expense.text = if (record.expenseAmount > 0)
        "💸 ${record.expenseAmount} ${record.expenseCurrency} · ${record.expenseCategory}" else ""
    holder.income.text = if (record.incomeAmount > 0)
        "💰 ${record.incomeAmount} ${record.incomeCurrency} · ${record.incomeSource}" else ""
    holder.notes.text = if (record.notes.isNotBlank()) "📋 ${record.notes}" else ""

    holder.expense.visibility = if (record.expenseAmount > 0) View.VISIBLE else View.GONE
    holder.income.visibility = if (record.incomeAmount > 0) View.VISIBLE else View.GONE
    holder.notes.visibility = if (record.notes.isNotBlank()) View.VISIBLE else View.GONE

    holder.deleteBtn.setOnClickListener {
        onDeleteClick(docId)
    }
}

override fun getItemCount() = records.size
}