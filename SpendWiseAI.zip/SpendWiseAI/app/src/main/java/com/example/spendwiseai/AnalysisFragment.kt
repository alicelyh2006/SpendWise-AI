package com.example.spendwiseai

import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.components.Legend
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import com.github.mikephil.charting.utils.ColorTemplate
import androidx.fragment.app.viewModels
import com.example.spendwiseai.databinding.FragmentAnalysisBinding
import java.time.YearMonth
import java.time.format.TextStyle
import java.util.Locale

class AnalysisFragment : Fragment(R.layout.fragment_analysis) {

    private val viewModel: AnalysisViewModel by activityViewModels()
    private var _binding: FragmentAnalysisBinding? = null
    private val binding get() = _binding!!

    private var viewYearMonth: YearMonth? = null

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        _binding = FragmentAnalysisBinding.bind(view)

        //pie chart
        val incomeChart = view.findViewById<PieChart>(R.id.income)
        val expensesChart = view.findViewById<PieChart>(R.id.expenses)

        //set initial year and month
        val current = YearMonth.now()
        viewYearMonth = current
        binding.viewMonthText.text = "${current.month.getDisplayName(TextStyle.FULL, Locale.getDefault())} ${current.year}"

        viewModel.loadRecordsForMonth(current.year, current.month.value - 1)

        //set click listener to open MonthYearPickerFragment
        binding.viewMonthRow.setOnClickListener {
            val picker = ViewMonthYearPickerFragment { selectedYearMonth ->
                viewYearMonth = selectedYearMonth
                val formatted =
                    "${selectedYearMonth.month.name.lowercase().replaceFirstChar { it.uppercase() }
                    } ${selectedYearMonth.year}"
                binding.viewMonthText.text = formatted

                viewModel.loadRecordsForMonth(selectedYearMonth.year, selectedYearMonth.month.value - 1)
            }
            picker.show(parentFragmentManager, "monthYearPicker")
        }

        //remaining limit
        viewModel.spendingStatus.observe(viewLifecycleOwner) { (title, message) ->
            android.util.Log.d("SpendingStatus", "UI updated: $title | $message")
            binding.remainingLimitTitle.text = title
            binding.remainingLimitMessage.text = message
        }

        //goals
        val recyclerView = view.findViewById<RecyclerView>(R.id.goalRecyclerView)
        val newGoal = view.findViewById<View>(R.id.new_goal)
        val goals = mutableListOf<Goal>()
        val adapter = GoalAdapter(goals) { goal ->
            EditGoalSheet.newInstance(goal).show(parentFragmentManager, "EditGoalSheet")

        }

        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = adapter

        viewModel.incomeEntries.observe(viewLifecycleOwner) { entries ->
            setupPieChart(incomeChart, entries, "Income", isExpense = false)
        }

        viewModel.expensesEntries.observe(viewLifecycleOwner) { entries ->
            setupPieChart(expensesChart, entries, "Expenses", isExpense = true)
        }

        newGoal.setOnClickListener {
            CreateGoalSheet().show(
                parentFragmentManager,
                "CreateGoalSheet"
            )
        }

        viewModel.goals.observe(viewLifecycleOwner) { updatedGoals ->
            goals.clear()
            goals.addAll(updatedGoals)
            adapter.notifyDataSetChanged()
        }

    }

    private fun setupPieChart(chart: PieChart, entries: List<PieEntry>, centerText: String, isExpense: Boolean) {
        val dataSet = PieDataSet(entries, "").apply {
            colors = entries.map { entry ->
                viewModel.getColor(entry.label)
            }
            valueTextColor = Color.BLACK
            valueTextSize = 14f
            sliceSpace = 2f
            valueLinePart1OffsetPercentage = 80f
            valueLinePart1Length = 0.5f
            valueLinePart2Length = 0.4f
            yValuePosition = PieDataSet.ValuePosition.OUTSIDE_SLICE
            xValuePosition = PieDataSet.ValuePosition.OUTSIDE_SLICE
        }

        dataSet.valueFormatter = RMValueFormatter()

        chart.apply {
            data = PieData(dataSet)
            description.isEnabled = false
            this.centerText = centerText
            setDrawCenterText(true)
            setCenterTextSize(14f)
            setCenterTextColor(Color.BLACK)
            animateY(1000)
            invalidate()
        }

        setupLegendCenter(chart)

    }

    private fun setupLegendCenter(chart: PieChart) {
        val legend = chart.legend
        legend.isEnabled = true
        legend.horizontalAlignment = Legend.LegendHorizontalAlignment.CENTER
        legend.verticalAlignment = Legend.LegendVerticalAlignment.BOTTOM
        legend.orientation = Legend.LegendOrientation.HORIZONTAL
        legend.setDrawInside(false)
        legend.textSize = 14f
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}