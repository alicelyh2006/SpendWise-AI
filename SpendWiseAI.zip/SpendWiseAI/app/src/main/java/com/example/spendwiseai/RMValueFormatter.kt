package com.example.spendwiseai

import com.github.mikephil.charting.formatter.ValueFormatter

class RMValueFormatter : ValueFormatter() {
    override fun getFormattedValue(value: Float): String {
        return "RM%.2f".format(value)
    }
}