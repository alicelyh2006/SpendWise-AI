package com.example.spendwiseai

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class HomeFragment : Fragment(R.layout.fragment_home) {

    // Share the SAME ViewModel instance used by all other fragments
    private val viewModel: AnalysisViewModel by activityViewModels()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val homeName   = view.findViewById<TextView>(R.id.homeName)
        val walletText = view.findViewById<TextView>(R.id.walletBalance)

        // Fetch user name from Firestore (unchanged)
        val user = FirebaseAuth.getInstance().currentUser
        if (user != null) {
            FirebaseFirestore.getInstance()
                .collection("users")
                .document(user.uid)
                .get()
                .addOnSuccessListener { doc ->
                    homeName.text = "${doc.getString("name") ?: "User"}!"
                }
                .addOnFailureListener {
                    homeName.text = "User!"
                }
        }

        // Observe wallet balance — updates automatically whenever records change
        viewModel.walletBalance.observe(viewLifecycleOwner) { balance ->
            walletText.text = "RM %.2f".format(balance)
        }

        // Trigger a fresh load so balance is up to date when this screen opens
        viewModel.updateGoalsWithRecords()
    }
}