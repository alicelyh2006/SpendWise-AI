package com.example.spendwiseai

import android.R
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import kotlin.apply

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {

        Log.e("ReminderReceiver", "⭐⭐⭐ RECEIVER TRIGGERED ⭐⭐⭐")
        Log.e("ReminderReceiver", "Action: ${intent.action}")
        Log.e("ReminderReceiver", "Time: ${System.currentTimeMillis()}")

        val msg = intent.getStringExtra("msg") ?: "Time to check your SpendWise!"
        Log.e("ReminderReceiver", "Message: $msg")

        try {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channelId = "reminder_channel"

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    channelId,
                    "Daily Reminders",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Channel for calendar reminders"
                    enableVibration(true)
                    enableLights(true)
                    setShowBadge(true)
                }
                manager.createNotificationChannel(channel)
                Log.e("ReminderReceiver", "Channel created/verified")
            }


            val notification = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(R.drawable.ic_dialog_info)
                .setContentTitle("SpendWise AI Reminder")
                .setContentText(msg)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setAutoCancel(true)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .build()

            val notificationId = (System.currentTimeMillis() % 10000).toInt()
            manager.notify(notificationId, notification)

            Log.e("ReminderReceiver", "✅ Notification sent with ID: $notificationId")

        } catch (e: Exception) {
            Log.e("ReminderReceiver", "❌ Error sending notification", e)
        }
    }
}