package com.example.spendwiseai

import android.util.Log
import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.ai.client.generativeai.GenerativeModel
import kotlinx.coroutines.launch

class ChatViewModel : ViewModel() {
    val messageList = mutableStateListOf<MessageModel>()
    val generativeModel : GenerativeModel = GenerativeModel(
        modelName = "gemini-2.5-flash",
        apiKey = "AIzaSyD7TloJJPKxqnpgsF3IlfHBUFl2_TKdLlg"
    )

    private val systemPrompt = """
        You are a Malaysian financial coach. Your main audience are Malaysians and your main task is to guide Malaysians on creating a budget, giving advices on goals setting and improving user's spending habits. When a user seeks advice from you, always ask the following information: minimum income per month, total expenses each month for the past three months, then only give your answer based on the user's background. Keep your answer short and precise. If a user asks something that unrelates to financial problems, reply with "I'm sorry, I can only trained to give financial advices. Feel free to ask me anything in terms of savings~" Be warmth and friendly at all times. Try your best to give advice based on Malaysian's spending habit. Try your best to speak in English.
    """.trimIndent()

    fun sendMessage(question : String, onMessageAdded: () -> Unit) {
        viewModelScope.launch {
            messageList.add(MessageModel(question, "user"))
            onMessageAdded()

            val chat = generativeModel.startChat()

            val fullPrompt = "$systemPrompt\nUser: $question"
            val response = chat.sendMessage(fullPrompt)

            val answer = response.toString()
            messageList.add(MessageModel(response.text.toString(), "model"))
            onMessageAdded()
        }
    }
}