package com.example.spendwiseai

import android.animation.ValueAnimator
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.widget.CalendarView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class CalendarFragment : Fragment(R.layout.fragment_calendar) {

    private val viewModel: AnalysisViewModel by activityViewModels()
    private var selectedDate = Calendar.getInstance()
    private var selectedTime = Calendar.getInstance()
    private val PERMISSION_REQUEST_CODE = 1001

    // UI components
    private lateinit var calendarView: CalendarView
    private lateinit var statusText: TextView
    private lateinit var selectTimeBtn: Button
    private lateinit var remarkInput: EditText
    private lateinit var doneBtn: Button
    private lateinit var expenseAmount: EditText
    private lateinit var incomeAmount: EditText
    private lateinit var notesInput: EditText

    // Spinners
    private lateinit var currencySpinnerExpense: Spinner
    private lateinit var currencySpinnerIncome: Spinner
    private lateinit var expenseCategorySpinner: Spinner
    private lateinit var incomeSourceSpinner: Spinner

    // Toggle headers
    private lateinit var toggleReminder: LinearLayout
    private lateinit var toggleExpense: LinearLayout
    private lateinit var toggleIncome: LinearLayout

    // Toggle content panels
    private lateinit var contentReminder: LinearLayout
    private lateinit var contentExpense: LinearLayout
    private lateinit var contentIncome: LinearLayout

    // Toggle dividers
    private lateinit var dividerReminder: View
    private lateinit var dividerExpense: View
    private lateinit var dividerIncome: View

    // Arrow indicators
    private lateinit var arrowReminder: TextView
    private lateinit var arrowExpense: TextView
    private lateinit var arrowIncome: TextView

    // Record display
    private lateinit var recordRecyclerView: RecyclerView
    private val recordList = mutableListOf<Pair<String, Record>>()
    private lateinit var recordAdapter: RecordAdapter
    private lateinit var emptyRecordText: TextView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val rootView = inflater.inflate(R.layout.fragment_calendar, container, false)

        initViews(rootView)

        recordAdapter = RecordAdapter(recordList) { docId -> deleteRecord(docId) }
        recordRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        recordRecyclerView.adapter = recordAdapter

        setupSpinners()
        createNotificationChannel()
        checkNotificationPermission()
        setupListeners()
        setupToggles()

        return rootView
    }

    private fun initViews(rootView: View) {
        calendarView = rootView.findViewById(R.id.calendarView)
        statusText = rootView.findViewById(R.id.statusText)
        selectTimeBtn = rootView.findViewById(R.id.selectTimeBtn)
        remarkInput = rootView.findViewById(R.id.remarkInput)
        doneBtn = rootView.findViewById(R.id.doneBtn)
        expenseAmount = rootView.findViewById(R.id.expenseAmount)
        incomeAmount = rootView.findViewById(R.id.incomeAmount)
        notesInput = rootView.findViewById(R.id.notesInput)
        currencySpinnerExpense = rootView.findViewById(R.id.currencySpinnerExpense)
        currencySpinnerIncome = rootView.findViewById(R.id.currencySpinnerIncome)
        expenseCategorySpinner = rootView.findViewById(R.id.expenseCategorySpinner)
        incomeSourceSpinner = rootView.findViewById(R.id.incomeSourceSpinner)
        recordRecyclerView = rootView.findViewById(R.id.recordRecyclerView)
        emptyRecordText = rootView.findViewById(R.id.emptyRecordText)

        // Toggles
        toggleReminder = rootView.findViewById(R.id.toggleReminder)
        toggleExpense = rootView.findViewById(R.id.toggleExpense)
        toggleIncome = rootView.findViewById(R.id.toggleIncome)
        contentReminder = rootView.findViewById(R.id.contentReminder)
        contentExpense = rootView.findViewById(R.id.contentExpense)
        contentIncome = rootView.findViewById(R.id.contentIncome)
        dividerReminder = rootView.findViewById(R.id.dividerReminder)
        dividerExpense = rootView.findViewById(R.id.dividerExpense)
        dividerIncome = rootView.findViewById(R.id.dividerIncome)
        arrowReminder = rootView.findViewById(R.id.arrowReminder)
        arrowExpense = rootView.findViewById(R.id.arrowExpense)
        arrowIncome = rootView.findViewById(R.id.arrowIncome)
    }

    private fun setupToggles() {
        toggleReminder.setOnClickListener { toggleSection(contentReminder, dividerReminder, arrowReminder) }
        toggleExpense.setOnClickListener { toggleSection(contentExpense, dividerExpense, arrowExpense) }
        toggleIncome.setOnClickListener { toggleSection(contentIncome, dividerIncome, arrowIncome) }
    }

    private fun toggleSection(content: LinearLayout, divider: View, arrow: TextView) {
        val isExpanded = content.visibility == View.VISIBLE
        if (isExpanded) {
            // Collapse
            content.visibility = View.GONE
            divider.visibility = View.GONE
            arrow.text = "▼"
        } else {
            // Expand
            content.visibility = View.VISIBLE
            divider.visibility = View.VISIBLE
            arrow.text = "▲"
        }
    }

    private fun setupSpinners() {
        val currencies = arrayOf(
            "USD ($)", "EUR (€)", "GBP (£)", "JPY (¥)", "CNY (¥)",
            "SGD (S$)", "MYR (RM)", "IDR (Rp)", "THB (฿)", "VND (₫)"
        )
        val currencyAdapter = ArrayAdapter(requireContext(), R.layout.item_spinner, currencies)
        currencyAdapter.setDropDownViewResource(R.layout.spinner_dropdown_item)
        currencySpinnerExpense.adapter = currencyAdapter
        currencySpinnerIncome.adapter = currencyAdapter

        val expenseCategories = arrayOf(
            "🍔 Food & Dining", "🚗 Transportation", "🛍️ Shopping", "🎬 Entertainment",
            "🏠 Bills & Utilities", "🏥 Healthcare", "📚 Education", "✈️ Travel",
            "🛒 Groceries", "🏢 Rent/Mortgage", "📱 Phone & Internet", "🐶 Pet Expenses",
            "👕 Clothing", "💪 Fitness", "💇 Personal Care", "🎁 Gifts", "📦 Insurance",
            "☕ Coffee & Snacks", "🍷 Nightlife", "📚 Books & Hobbies", "💻 Gadgets", "🚀 Other"
        )
        val expenseAdapter = ArrayAdapter(requireContext(), R.layout.item_spinner, expenseCategories)
        expenseAdapter.setDropDownViewResource(R.layout.spinner_dropdown_item)
        expenseCategorySpinner.adapter = expenseAdapter

        val incomeSources = arrayOf(
            "💰 Salary", "👪 Allowance", "💼 Part Time Job", "🏢 Full Time Job",
            "💻 Freelance", "🏭 Business", "📈 Investment", "🎁 Gift", "💳 Refund",
            "🎯 Bonus", "📊 Commission", "🏠 Rental Income", "💵 Dividend",
            "🪙 Cryptocurrency", "🎓 Scholarship", "👴 Pension", "🎰 Lottery", "💸 Other"
        )
        val incomeAdapter = ArrayAdapter(requireContext(), R.layout.item_spinner, incomeSources)
        incomeAdapter.setDropDownViewResource(R.layout.spinner_dropdown_item)
        incomeSourceSpinner.adapter = incomeAdapter
    }

    private fun setupListeners() {
        calendarView.setOnDateChangeListener { _, year, month, day ->
            selectedDate.set(year, month, day)
            selectedDate.set(Calendar.HOUR_OF_DAY, 0)
            selectedDate.set(Calendar.MINUTE, 0)
            selectedDate.set(Calendar.SECOND, 0)
            selectedDate.set(Calendar.MILLISECOND, 0)

            val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val dateKey = dateFormat.format(Date(selectedDate.timeInMillis))
            statusText.text = "Selected Date: $dateKey"
            updateRecordSection(dateKey)
        }

        selectTimeBtn.setOnClickListener {
            val remark = remarkInput.text.toString()
            if (remark.isBlank()) {
                Toast.makeText(requireContext(), "Please enter a remark first", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            showTimePicker(remark)
        }

        doneBtn.setOnClickListener {
            saveAllData()
        }
    }

    private fun showTimePicker(remark: String) {
        val now = Calendar.getInstance()
        TimePickerDialog(requireContext(), { _, hour, minute ->
            selectedTime.set(Calendar.HOUR_OF_DAY, hour)
            selectedTime.set(Calendar.MINUTE, minute)
            selectedTime.set(Calendar.SECOND, 0)
            selectedTime.set(Calendar.MILLISECOND, 0)

            val reminderDateTime = Calendar.getInstance().apply {
                set(
                    selectedDate.get(Calendar.YEAR), selectedDate.get(Calendar.MONTH),
                    selectedDate.get(Calendar.DAY_OF_MONTH), hour, minute, 0
                )
            }

            if (reminderDateTime.timeInMillis <= Calendar.getInstance().timeInMillis) {
                reminderDateTime.add(Calendar.DAY_OF_MONTH, 1)
                Toast.makeText(requireContext(), "Selected time has passed, set for tomorrow", Toast.LENGTH_SHORT).show()
            }

            selectTimeBtn.text = String.format("⏰ Time set: %02d:%02d", hour, minute)
            scheduleNotification(reminderDateTime.timeInMillis, remark)
        }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), true).show()
    }

    private fun saveAllData() {
        val remark = remarkInput.text.toString()
        val expenseAmt = expenseAmount.text.toString().toDoubleOrNull() ?: 0.0
        val incomeAmt = incomeAmount.text.toString().toDoubleOrNull() ?: 0.0
        val notes = notesInput.text.toString()

        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val selectedDateStr = dateFormat.format(Date(selectedDate.timeInMillis))
        val selectedTimeStr = selectTimeBtn.text.toString().replace("⏰ Time set: ", "")

        val record = Record(
            remark = remark,
            expenseAmount = expenseAmt,
            expenseCurrency = currencySpinnerExpense.selectedItem.toString(),
            expenseCategory = expenseCategorySpinner.selectedItem.toString(),
            incomeAmount = incomeAmt,
            incomeCurrency = currencySpinnerIncome.selectedItem.toString(),
            incomeSource = incomeSourceSpinner.selectedItem.toString(),
            notes = notes,
            date = selectedDateStr,
            time = selectedTimeStr
        )

        val summary = StringBuilder().apply {
            append("📅 Date: $selectedDateStr\n")
            append("⏰ Time: ${selectTimeBtn.text}\n\n")
            if (remark.isNotBlank()) append("📝 Remark: $remark\n\n")
            if (expenseAmt > 0) append("💸 EXPENSE:\n   Amount: $expenseAmt ${currencySpinnerExpense.selectedItem}\n   Category: ${expenseCategorySpinner.selectedItem}\n\n")
            if (incomeAmt > 0) append("💰 INCOME:\n   Amount: $incomeAmt ${currencySpinnerIncome.selectedItem}\n   Source: ${incomeSourceSpinner.selectedItem}\n\n")
            if (notes.isNotBlank()) append("📋 Notes: $notes\n")
        }

        val user = FirebaseAuth.getInstance().currentUser
        if (user != null) {
            FirebaseFirestore.getInstance()
                .collection("users")
                .document(user.uid)
                .collection("records")
                .add(record)
                .addOnSuccessListener {
                    Toast.makeText(requireContext(), "Record saved!", Toast.LENGTH_SHORT).show()
                    clearInputs()
                    updateRecordSection(selectedDateStr)
                    viewModel.loadRecordsForMonth(selectedDate.get(Calendar.YEAR), selectedDate.get(Calendar.MONTH))
                    viewModel.updateGoalsWithRecords()
                }
                .addOnFailureListener { e ->
                    Toast.makeText(requireContext(), "Failed to save record: ${e.message}", Toast.LENGTH_SHORT).show()
                }
        } else {
            Toast.makeText(requireContext(), "User not logged in", Toast.LENGTH_SHORT).show()
        }

        AlertDialog.Builder(requireContext())
            .setTitle("✅ Data Saved Successfully")
            .setMessage(summary.toString())
            .setPositiveButton("OK") { _, _ -> clearInputs() }
            .show()
    }

    private fun clearInputs() {
        remarkInput.text.clear()
        expenseAmount.text.clear()
        incomeAmount.text.clear()
        notesInput.text.clear()
        selectTimeBtn.text = "Choose Time"
    }

    private fun updateRecordSection(dateKey: String) {
        val user = FirebaseAuth.getInstance().currentUser ?: return

        FirebaseFirestore.getInstance()
            .collection("users")
            .document(user.uid)
            .collection("records")
            .whereEqualTo("date", dateKey)
            .get()
            .addOnSuccessListener { snapshot ->
                recordList.clear()
                snapshot.documents.forEach { doc ->
                    doc.toObject(Record::class.java)?.let { record ->
                        recordList.add(Pair(doc.id, record))
                    }
                }
                recordAdapter.notifyDataSetChanged()
                emptyRecordText.visibility = if (recordList.isEmpty()) View.VISIBLE else View.GONE
                recordRecyclerView.visibility = if (recordList.isEmpty()) View.GONE else View.VISIBLE
            }
            .addOnFailureListener {
                recordList.clear()
                recordAdapter.notifyDataSetChanged()
            }
    }

    private fun deleteRecord(docId: String) {
        val user = FirebaseAuth.getInstance().currentUser ?: return
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val dateKey = dateFormat.format(Date(selectedDate.timeInMillis))

        FirebaseFirestore.getInstance()
            .collection("users")
            .document(user.uid)
            .collection("records")
            .document(docId)
            .delete()
            .addOnSuccessListener {
                Toast.makeText(requireContext(), "Record deleted", Toast.LENGTH_SHORT).show()
                updateRecordSection(dateKey)
                viewModel.loadRecordsForMonth(selectedDate.get(Calendar.YEAR), selectedDate.get(Calendar.MONTH))
                viewModel.updateGoalsWithRecords()
            }
            .addOnFailureListener { e ->
                Toast.makeText(requireContext(), "Failed to delete: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "reminder_channel", "Daily Reminders", NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Channel for calendar reminders"
                enableVibration(true)
                enableLights(true)
                setShowBadge(true)
            }
            val notificationManager = requireContext().getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun checkNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(requireContext(), android.Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), PERMISSION_REQUEST_CODE)
            }
        }
    }

    private fun scheduleNotification(time: Long, message: String) {
        try {
            val intent = Intent(requireContext(), ReminderReceiver::class.java).apply {
                putExtra("msg", message)
                action = "com.example.spendwiseai.REMINDER_ACTION"
            }
            val pendingIntent = PendingIntent.getBroadcast(
                requireContext(), (time % Integer.MAX_VALUE).toInt(), intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val alarmManager = requireContext().getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarmManager.cancel(pendingIntent)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, pendingIntent)
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, time, pendingIntent)
            }

            val timeStr = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(time))
            Toast.makeText(requireContext(), "✓ Reminder set for $timeStr", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(requireContext(), "Failed to set reminder: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST_CODE) {
            val message = if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                "Notification permission granted"
            else
                "Notification permission denied. You won't receive reminders"
            Toast.makeText(requireContext(), message, Toast.LENGTH_LONG).show()
        }
    }
}
