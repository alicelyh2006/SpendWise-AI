package com.example.spendwiseai

data class Goal(
    val id: String = "",
    val name: String = "",
    val targetAmount: Float = 0f,
    var savedAmount: Float = 0f,
    val startMonth: String = "",
    val deadline: String = ""
)