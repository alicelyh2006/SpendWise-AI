package com.example.spendwiseai

import android.graphics.Color
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.github.mikephil.charting.data.PieEntry
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.*

class AnalysisViewModel : ViewModel() {

    private val _incomeEntries = MutableLiveData<List<PieEntry>>()
    val incomeEntries : LiveData<List<PieEntry>> = _incomeEntries

    private val _expensesEntries = MutableLiveData<List<PieEntry>>()
    val expensesEntries : LiveData<List<PieEntry>> = _expensesEntries

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    private var listener: ListenerRegistration? = null

    private val defaultColors = listOf(
        Color.parseColor("#FF5722"), Color.parseColor("#03A9F4"), Color.parseColor("#9C27B0"),
        Color.parseColor("#FFC107"), Color.parseColor("#4CAF50"), Color.parseColor("#FF9800"),
        Color.parseColor("#2196F3"), Color.parseColor("#00BCD4"), Color.LTGRAY
    )
    private val categoryColorMap = mutableMapOf<String, Int>()
    private var colorIndex = 0

    private val _spendingStatus = MutableLiveData<Pair<String, String>>()
    val spendingStatus: LiveData<Pair<String, String>> = _spendingStatus

    private val _goals = MutableLiveData<MutableList<Goal>>(mutableListOf())
    val goals: LiveData<MutableList<Goal>> = _goals

    // --- NEW: wallet balance LiveData ---
    private val _walletBalance = MutableLiveData<Double>()
    val walletBalance: LiveData<Double> = _walletBalance

    init {
        loadGoals()
    }

    fun addGoal(goal: Goal) {
        val currentList = _goals.value ?: mutableListOf()
        currentList.add(goal)
        _goals.value = currentList
    }

    fun loadGoals() {
        val user = FirebaseAuth.getInstance().currentUser ?: return
        val db = FirebaseFirestore.getInstance()

        db.collection("users")
            .document(user.uid)
            .collection("goals")
            .get()
            .addOnSuccessListener { snapshot ->
                val list = snapshot.documents.mapNotNull { doc ->
                    doc.toObject(Goal::class.java)?.copy(id = doc.id)
                }.toMutableList()
                _goals.value = list
                updateGoalsWithRecords()
            }
    }

    fun updateGoalsWithRecords() {
        android.util.Log.d("SpendingStatus", "updateGoalsWithRecords called")
        val user = FirebaseAuth.getInstance().currentUser ?: return
        val db = FirebaseFirestore.getInstance()

        db.collection("users").document(user.uid).collection("records")
            .get()
            .addOnSuccessListener { recordSnapshot ->
                val records = recordSnapshot.documents.mapNotNull { it.toObject(Record::class.java) }
                android.util.Log.d("SpendingStatus", "records count: ${records.size}")

                // --- NEW: compute and post wallet balance here ---
                val totalIncome  = records.sumOf { it.incomeAmount }
                val totalExpense = records.sumOf { it.expenseAmount }
                _walletBalance.postValue(totalIncome - totalExpense)

                db.collection("users").document(user.uid).collection("goals")
                    .get()
                    .addOnSuccessListener { goalSnapshot ->
                        val goalList = goalSnapshot.documents.mapNotNull { doc ->
                            doc.toObject(Goal::class.java)?.copy(id = doc.id, savedAmount = 0f)
                        }.toMutableList()
                        android.util.Log.d("SpendingStatus", "goals count: ${goalList.size}")

                        val sortedGoals = goalList.sortedBy { parseMonthYear(it.deadline)?.timeInMillis ?: Long.MAX_VALUE }

                        val now = Calendar.getInstance()
                        val currentYear = now.get(Calendar.YEAR)
                        val currentMonth = now.get(Calendar.MONTH)

                        val monthsWithRecords = records.mapNotNull { record ->
                            val date = dateFormat.parse(record.date) ?: return@mapNotNull null
                            val cal = Calendar.getInstance()
                            cal.time = date
                            Pair(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH))
                        }.toSet().sortedWith(compareBy({ it.first }, { it.second }))
                            .filter { (year, month) ->
                                year < currentYear || (year == currentYear && month < currentMonth)
                            }

                        monthsWithRecords.forEach { (year, month) ->
                            var monthlySavings = 0f
                            records.forEach { record ->
                                val date = dateFormat.parse(record.date) ?: return@forEach
                                val cal = Calendar.getInstance()
                                cal.time = date
                                if (cal.get(Calendar.YEAR) == year && cal.get(Calendar.MONTH) == month) {
                                    monthlySavings += record.incomeAmount.toFloat()
                                    monthlySavings -= record.expenseAmount.toFloat()
                                }
                            }

                            if (monthlySavings <= 0f) return@forEach

                            var remaining = monthlySavings

                            sortedGoals.forEach { goal ->
                                if (remaining <= 0f) return@forEach
                                val startCal = parseMonthYear(goal.startMonth) ?: return@forEach
                                val endCal = parseMonthYear(goal.deadline) ?: return@forEach
                                val thisMonth = Calendar.getInstance().apply {
                                    set(year, month, 1, 0, 0, 0)
                                    set(Calendar.MILLISECOND, 0)
                                }
                                if (thisMonth.before(startCal) || thisMonth.after(endCal)) return@forEach
                                val stillNeeded = (goal.targetAmount - goal.savedAmount).coerceAtLeast(0f)
                                if (stillNeeded <= 0f) return@forEach
                                val totalMonths = ((endCal.get(Calendar.YEAR) - startCal.get(Calendar.YEAR)) * 12 +
                                        (endCal.get(Calendar.MONTH) - startCal.get(Calendar.MONTH)) + 1).coerceAtLeast(1)
                                val monthlyTarget = goal.targetAmount / totalMonths
                                val allocated = remaining.coerceAtMost(monthlyTarget).coerceAtMost(stillNeeded)
                                goal.savedAmount += allocated
                                remaining -= allocated
                            }

                            if (remaining > 0f) {
                                sortedGoals.forEach { goal ->
                                    if (remaining <= 0f) return@forEach
                                    val startCal = parseMonthYear(goal.startMonth) ?: return@forEach
                                    val endCal = parseMonthYear(goal.deadline) ?: return@forEach
                                    val thisMonth = Calendar.getInstance().apply {
                                        set(year, month, 1, 0, 0, 0)
                                        set(Calendar.MILLISECOND, 0)
                                    }
                                    if (thisMonth.before(startCal) || thisMonth.after(endCal)) return@forEach
                                    val stillNeeded = (goal.targetAmount - goal.savedAmount).coerceAtLeast(0f)
                                    if (stillNeeded <= 0f) return@forEach
                                    val allocated = remaining.coerceAtMost(stillNeeded)
                                    goal.savedAmount += allocated
                                    remaining -= allocated
                                }
                            }
                        }

                        _goals.value = goalList
                        calculateSpendingStatus(records, goalList)
                    }
            }
    }

    private fun parseMonthYear(monthYear: String): Calendar? {
        return try {
            val format = SimpleDateFormat("MMMM yyyy", Locale.getDefault())
            val date = format.parse(monthYear) ?: return null
            Calendar.getInstance().apply {
                time = date
                set(Calendar.DAY_OF_MONTH, 1)
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
        } catch (e: Exception) {
            null
        }
    }

    fun updateGoal(updated: Goal) {
        val current = _goals.value ?: return
        val index = current.indexOfFirst { it.id == updated.id }
        if (index != -1) {
            current[index] = updated
            _goals.value = current
        }
    }

    fun removeGoal(goalId: String) {
        val current = _goals.value ?: return
        current.removeAll { it.id == goalId }
        _goals.value = current
    }

    fun loadRecordsForMonth(year: Int, month: Int) {
        listener?.remove()

        val user = FirebaseAuth.getInstance().currentUser ?: return
        val db = FirebaseFirestore.getInstance()

        listener = db.collection("users")
            .document(user.uid)
            .collection("records")
            .addSnapshotListener { snapshot, error ->
                if (error != null) return@addSnapshotListener

                val incomeMap = mutableMapOf<String, Float>()
                val expenseMap = mutableMapOf<String, Float>()

                snapshot?.documents?.forEach { doc ->
                    val record = doc.toObject(Record::class.java)
                    record?.let {
                        val recordDate = dateFormat.parse(it.date) ?: return@let
                        val cal = Calendar.getInstance()
                        cal.time = recordDate

                        if (cal.get(Calendar.YEAR) == year && cal.get(Calendar.MONTH) == month) {
                            if (it.incomeAmount > 0) {
                                val prev = incomeMap[it.incomeSource] ?: 0f
                                incomeMap[it.incomeSource] = prev + it.incomeAmount.toFloat()
                                assignColor(it.incomeSource)
                            }
                            if (it.expenseAmount > 0) {
                                val prev = expenseMap[it.expenseCategory] ?: 0f
                                expenseMap[it.expenseCategory] = prev + it.expenseAmount.toFloat()
                                assignColor(it.expenseCategory)
                            }
                        }
                    }
                }

                _incomeEntries.value = incomeMap.map { PieEntry(it.value, it.key) }
                _expensesEntries.value = expenseMap.map { PieEntry(it.value, it.key) }

                // --- NEW: also refresh balance whenever records snapshot changes ---
                updateGoalsWithRecords()
            }
    }

    private fun calculateSpendingStatus(records: List<Record>, goalList: List<Goal>) {
        val now = Calendar.getInstance()
        val currentYear = now.get(Calendar.YEAR)
        val currentMonth = now.get(Calendar.MONTH)

        var monthlyIncome = 0f
        var monthlyExpense = 0f
        records.forEach { record ->
            val date = dateFormat.parse(record.date) ?: return@forEach
            val cal = Calendar.getInstance()
            cal.time = date
            if (cal.get(Calendar.YEAR) == currentYear && cal.get(Calendar.MONTH) == currentMonth) {
                monthlyIncome += record.incomeAmount.toFloat()
                monthlyExpense += record.expenseAmount.toFloat()
            }
        }

        val thisMonth = Calendar.getInstance().apply {
            set(currentYear, currentMonth, 1, 0, 0, 0)
            set(Calendar.MILLISECOND, 0)
        }

        var totalMonthlySavingsRequired = 0f
        goalList.forEach { goal ->
            val startCal = parseMonthYear(goal.startMonth) ?: return@forEach
            val endCal = parseMonthYear(goal.deadline) ?: return@forEach
            if (thisMonth.before(startCal) || thisMonth.after(endCal)) return@forEach
            val remainingAmount = (goal.targetAmount - goal.savedAmount).coerceAtLeast(0f)
            val remainingMonths = ((endCal.get(Calendar.YEAR) - currentYear) * 12 +
                    (endCal.get(Calendar.MONTH) - currentMonth) + 1).coerceAtLeast(1)
            totalMonthlySavingsRequired += remainingAmount / remainingMonths
        }

        val spendingLimit = (monthlyIncome - totalMonthlySavingsRequired).coerceAtLeast(0f)
        val remainingToSpend = (spendingLimit - monthlyExpense).coerceAtLeast(0f)
        val spentRatio = if (spendingLimit > 0f) monthlyExpense / spendingLimit else 1f

        val title = when {
            spentRatio < 0.2f -> "You're good to go!"
            spentRatio < 0.6f -> "Still OK!"
            else -> "Be careful!"
        }

        val message = "You have RM${remainingToSpend.toInt()} left to spend this month!"
        _spendingStatus.value = Pair(title, message)
    }

    private fun assignColor(category: String) {
        if (!categoryColorMap.containsKey(category)) {
            categoryColorMap[category] = defaultColors[colorIndex % defaultColors.size]
            colorIndex++
        }
    }

    fun getColor(category: String): Int {
        return categoryColorMap[category] ?: Color.LTGRAY
    }

    override fun onCleared() {
        super.onCleared()
        listener?.remove()
    }
}