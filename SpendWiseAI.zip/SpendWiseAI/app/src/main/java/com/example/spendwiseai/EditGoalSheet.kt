package com.example.spendwiseai

import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.annotation.RequiresApi
import com.example.spendwiseai.databinding.FragmentCreateGoalSheetBinding
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import java.time.YearMonth
import androidx.fragment.app.activityViewModels
import com.example.spendwiseai.databinding.FragmentEditGoalSheetBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class EditGoalSheet : BottomSheetDialogFragment() {

    private val viewModel: AnalysisViewModel by activityViewModels()
    private lateinit var binding: FragmentEditGoalSheetBinding
    private var targetYearMonth: YearMonth? = null
    private var startYearMonth: YearMonth? = null

    companion object {
        fun newInstance(goal: Goal): EditGoalSheet {
            val sheet = EditGoalSheet()
            val args = Bundle().apply {
                putString("id", goal.id)
                putString("name", goal.name)
                putFloat("targetAmount", goal.targetAmount)
                putFloat("savedAmount", goal.savedAmount)
                putString("deadline", goal.deadline)
            }
            sheet.arguments = args
            return sheet
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentEditGoalSheetBinding.inflate(inflater,container,false)
        return binding.root
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val goalId = arguments?.getString("id") ?: ""

        arguments?.let { args ->
            binding.goalTitleInput.setText(args.getString("name"))
            binding.targetAmount.setText(args.getFloat("targetAmount").toInt().toString())
            binding.targetMonthText.text = args.getString("deadline").takeIf { it?.isNotEmpty() == true }
            binding.startMonthText.text = args.getString("startMonth").takeIf { it?.isNotEmpty() == true }
                ?: "Select Start Month and Year"
        }

        binding.startMonthRow.setOnClickListener {
            val picker = GoalMonthYearPickerFragment { selected ->
                val formatted = "${selected.month.name.lowercase().replaceFirstChar { it.uppercase() }} ${selected.year}"
                binding.startMonthText.text = formatted
                startYearMonth = selected
            }
            picker.show(parentFragmentManager, "startMonthPicker")
        }

        binding.targetMonthRow.setOnClickListener {
            val picker = GoalMonthYearPickerFragment { selected ->

                val formatted = "${
                    selected.month.name.lowercase().replaceFirstChar { it.uppercase() }
                } ${selected.year}"

                binding.targetMonthText.text = formatted
                targetYearMonth = selected
            }

            picker.show(parentFragmentManager, "targetMonthPicker")
        }

        binding.save.setOnClickListener {

            val user = FirebaseAuth.getInstance().currentUser ?: return@setOnClickListener
            val name = binding.goalTitleInput.text.toString()
            val amountText = binding.targetAmount.text.toString()
            val deadlineText = binding.targetMonthText.text.toString()
            val startText = binding.startMonthText.text.toString()

            if (name.isEmpty()) {
                binding.goalTitleInput.error = "Please enter goal name"; return@setOnClickListener
            }
            if (amountText.isEmpty()) {
                binding.targetAmount.error = "Please enter target amount"; return@setOnClickListener
            }
            if (deadlineText == getString(R.string.select_target_month_and_year_title)) {
                Toast.makeText(requireContext(), "Please select a target month and year", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (startText == "Select Start Month and Year") {
                Toast.makeText(requireContext(), "Please select a start month and year", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val updatedGoal = Goal(
                id = goalId,
                name = name,
                targetAmount = amountText.toFloat(),
                savedAmount = arguments?.getFloat("savedAmount") ?: 0f,
                startMonth = startText,
                deadline = deadlineText
            )

            val db = FirebaseFirestore.getInstance()
            db.collection("users")
                .document(user.uid)
                .collection("goals")
                .document(goalId)
                .set(updatedGoal)
                .addOnSuccessListener {
                    viewModel.updateGoal(updatedGoal)
                    dismiss()
                }.addOnFailureListener { e ->
                    Toast.makeText(requireContext(), "Failed to update: ${e.message}",
                        Toast.LENGTH_SHORT).show()
                }

            //remember to remove these two lines
            viewModel.updateGoal(updatedGoal)
            dismiss()
        }

        binding.deleteGoalBtn.setOnClickListener {
            val user = FirebaseAuth.getInstance().currentUser ?: return@setOnClickListener
            FirebaseFirestore.getInstance()
                .collection("users")
                .document(user.uid)
                .collection("goals")
                .document(goalId)
                .delete()
                .addOnSuccessListener {
                    viewModel.removeGoal(goalId)
                    dismiss()
                }.addOnFailureListener { e ->
                    Toast.makeText(requireContext(), "Failed to delete: ${e.message}", Toast.LENGTH_SHORT).show()
                }

            //remember to remove these two lines
            viewModel.removeGoal(goalId)
            dismiss()
        }
    }
}