package com.example.spendwiseai

import android.graphics.Typeface
import android.text.SpannableString
import android.text.Spanned
import android.text.style.StyleSpan
import android.text.style.UnderlineSpan
import java.util.regex.Pattern

fun parseMarkdown(text: String): SpannableString {
    val spannable = SpannableString(text)

    // BOLD **text**
    val boldPattern = Pattern.compile("\\*\\*(.*?)\\*\\*")
    val boldMatcher = boldPattern.matcher(text)
    var offset = 0
    while (boldMatcher.find()) {
        val start = boldMatcher.start() - offset
        val end = boldMatcher.end() - offset - 4 // remove ** **
        spannable.setSpan(
            StyleSpan(Typeface.BOLD),
            start,
            end,
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        offset += 4 // account for removed **
    }

    // ITALIC *text*
    val italicPattern = Pattern.compile("\\*(.*?)\\*")
    val italicMatcher = italicPattern.matcher(spannable)
    offset = 0
    while (italicMatcher.find()) {
        val start = italicMatcher.start() - offset
        val end = italicMatcher.end() - offset - 2 // remove *
        spannable.setSpan(
            StyleSpan(Typeface.ITALIC),
            start,
            end,
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        offset += 2
    }

    // UNDERLINE __text__
    val underlinePattern = Pattern.compile("__(.*?)__")
    val underlineMatcher = underlinePattern.matcher(spannable)
    offset = 0
    while (underlineMatcher.find()) {
        val start = underlineMatcher.start() - offset
        val end = underlineMatcher.end() - offset - 4 // remove __ __
        spannable.setSpan(
            UnderlineSpan(),
            start,
            end,
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        offset += 4
    }

    // Remove all Markdown symbols from text
    val cleanText = text
        .replace("\\*\\*(.*?)\\*\\*".toRegex(), "$1")
        .replace("\\*(.*?)\\*".toRegex(), "$1")
        .replace("__(.*?)__".toRegex(), "$1")

    return SpannableString(cleanText).also { sp ->
        // Reapply spans to cleaned text
        // BOLD
        val matcher2 = boldPattern.matcher(text)
        offset = 0
        while (matcher2.find()) {
            val start = matcher2.start() - offset
            val end = matcher2.end() - offset - 4
            sp.setSpan(
                StyleSpan(Typeface.BOLD),
                start,
                end,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            offset += 4
        }
        // ITALIC
        val matcher3 = italicPattern.matcher(text)
        offset = 0
        while (matcher3.find()) {
            val start = matcher3.start() - offset
            val end = matcher3.end() - offset - 2
            sp.setSpan(
                StyleSpan(Typeface.ITALIC),
                start,
                end,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            offset += 2
        }
        // UNDERLINE
        val matcher4 = underlinePattern.matcher(text)
        offset = 0
        while (matcher4.find()) {
            val start = matcher4.start() - offset
            val end = matcher4.end() - offset - 4
            sp.setSpan(
                UnderlineSpan(),
                start,
                end,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            offset += 4
        }
    }
}