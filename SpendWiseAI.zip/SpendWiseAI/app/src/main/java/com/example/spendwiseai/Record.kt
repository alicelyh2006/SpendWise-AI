package com.example.spendwiseai

data class Record(
    val remark: String = "",
    val expenseAmount: Double = 0.0,
    val expenseCurrency: String = "",
    val expenseCategory: String = "",
    val incomeAmount: Double = 0.0,
    val incomeCurrency: String = "",
    val incomeSource: String = "",
    val notes: String = "",
    val date: String = "",
    val time: String = ""
)