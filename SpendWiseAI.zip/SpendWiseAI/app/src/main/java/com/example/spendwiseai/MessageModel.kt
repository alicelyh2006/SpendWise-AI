package com.example.spendwiseai

data class MessageModel(
    val message : String,
    val role : String,

)
